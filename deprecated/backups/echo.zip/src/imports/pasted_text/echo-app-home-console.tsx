Design a modern enterprise web application called ECHO, which stands for Executive Calls, Highlights & Outcomes. ECHO helps non-technical business users convert meeting recordings, Teams/Stream URLs, and transcripts into professional Minutes of Meeting, executive summaries, decisions, risks, and action items.

The product is for executives, project managers, operations teams, and business users with zero technical knowledge. The UI must feel simple, trustworthy, and action-oriented. Do not expose technical backend concepts on the main user screens. Hide model names, API keys, ASR, Dify, Azure OpenAI, Ollama, Whisper, ffmpeg, Playwright, VAD, and prompt files inside Settings or Advanced Admin screens only.

Create a polished SaaS-style product UI, not a marketing landing page. The first screen must be the actual application home screen. Make it a practical work console, not an analytics-first dashboard.

Visual style:
- Modern enterprise productivity app.
- Calm, professional, executive-ready.
- Clean left sidebar navigation.
- Light theme with strong contrast.
- Subtle accent color, preferably deep teal or executive blue, with neutral grays.
- Dense but readable layouts.
- 8px or smaller card radius.
- Clear typography hierarchy.
- Status badges, tables, tabs, segmented controls, icon buttons, progress indicators.
- Avoid playful visuals, oversized hero sections, decorative gradient blobs, and card-heavy marketing layouts.
- Product name in sidebar/top bar: ECHO.
- Include the subtitle somewhere appropriate: Executive Calls, Highlights & Outcomes.

Primary navigation:
- Home
- Create MoM
- Meeting Notes
- Action Items
- Queue
- Templates
- Settings

Admin/advanced navigation inside Settings:
- System Health
- Backend Settings
- Prompt Studio
- Storage & Retention
- Privacy & Compliance

Core user journey:
1. User opens ECHO.
2. User immediately sees a clear “Create meeting notes” area.
3. User pastes one or more Teams/Stream links, uploads one or more recordings, or uses an existing transcript.
4. User clicks Generate MoM or Add to Queue.
5. User sees friendly progress language.
6. User opens generated MoM.
7. User reviews, edits, approves, exports, or regenerates.
8. User can later search old MoMs and track action items.

Screen 1: Home / Work Console
This is the first screen and most important landing experience. It should be action-first, not analytics-first.

Top area:
- App header with ECHO logo, search, notifications, user/profile menu.
- Main heading: “Create meeting notes”
- Supporting text: “Paste meeting links, upload recordings, or reuse a transcript.”
- Large input module with tabs or segmented controls:
  - Meeting Links
  - Upload Recordings
  - Existing Transcript
- Meeting Links tab should show a multi-line paste area that supports multiple Teams/Stream URLs.
- Upload tab should show a drag-and-drop area for multiple audio/video files.
- Existing Transcript tab should allow selecting a saved transcript or pasting transcript text.
- Primary button: Generate MoM
- Secondary button: Add multiple recordings to queue
- Simple options visible: Meeting type, Template, Confidentiality.
- Keep technical settings hidden under a small Advanced link.

Below primary action area, in this order:
1. Processing Queue summary
   - Friendly wording: Waiting, Reading transcript, Transcribing, Creating MoM, Ready for review, Needs attention.
   - Show 3-5 active jobs with progress bars.
   - Avoid technical terms like ASR, backend, model.
2. Ready for Review
   - List meetings where MoM is generated but not approved.
   - Show meeting title, generated time, decisions count, action items count.
   - Primary row action: Review MoM.
3. Recent Meeting Notes
   - Searchable recent MoMs.
   - Show meeting title, date, meeting type, status, owner, and quick actions: Open, Export, Regenerate.
4. Open Action Items
   - Show top pending action items with owner, due date, and source meeting.

Screen 2: Create MoM
A fuller submission workspace for batch processing.
- Tabs: Meeting Links, Upload Recordings, Existing Transcript.
- Support multiple URLs and multiple video/audio files.
- Batch preview table: Meeting, Source, Type, Owner, Status.
- Metadata form:
  - Meeting title
  - Meeting type
  - Project/Department
  - Host
  - Tags
  - Confidentiality
- Template selector:
  - Executive MoM
  - Project Review
  - Client Call
  - Townhall
  - Demo/UAT
  - Incident Review
- Output options:
  - Summary
  - Full MoM
  - Action Items
  - Decisions
  - Risks
  - Email Draft
- Primary button: Generate MoM
- Secondary button: Add to Queue
- Tertiary button: Save Draft
- Use non-technical labels. Advanced technical options should be collapsed.

Screen 3: Queue
Design a simple processing queue for business users.
- Table columns:
  - Meeting
  - Source
  - Progress
  - Started
  - Owner
  - Status
  - Actions
- Friendly statuses:
  - Waiting
  - Reading transcript
  - Transcribing recording
  - Creating MoM
  - Ready for review
  - Needs attention
  - Completed
- Row actions:
  - Open
  - Retry
  - Cancel
  - Move up
- Top controls:
  - Pause queue
  - Resume queue
  - Retry items needing attention
  - Clear completed
- Failed/attention panel:
  - Explain issue in plain language.
  - Example: “We could not find a visible transcript. Upload the recording file or check that you have access.”
  - Button: Fix and retry.

Screen 4: Meeting Notes / History
Design a searchable archive of all generated meeting notes.
- Left filter panel:
  - Date range
  - Meeting type
  - Project
  - Owner
  - Source
  - Status
  - Tags
  - Confidentiality
- Saved views:
  - All Meeting Notes
  - My Meetings
  - Ready for Review
  - Completed
  - Needs Attention
  - Archived
- Main table/list:
  - Meeting title
  - Date
  - Meeting type
  - Participants count
  - Decisions count
  - Action items count
  - MoM version
  - Status
  - Quick actions: Open, Export, Regenerate
- Include bulk actions:
  - Export
  - Archive
  - Assign reviewer

Screen 5: Meeting Detail / Review
This is the most important detailed workspace.
- Header:
  - Meeting title
  - Date
  - Source link/file
  - Status badge
  - Tags
  - Confidentiality badge
  - Primary action: Approve MoM
  - Secondary actions: Export, Share, Regenerate
- Layout:
  - Main content area
  - Right insight/action panel
- Tabs in this order:
  1. Executive Summary
  2. Decisions
  3. Action Items
  4. Risks & Blockers
  5. Full MoM
  6. Transcript
  7. Versions
  8. Exports
- Executive Summary tab:
  - Brief summary
  - Key outcomes
  - Important decisions
  - Critical risks
  - Next steps
- Decisions tab:
  - Decision
  - Context
  - Owner or stakeholder
  - Date/time reference if available
- Action Items tab:
  - Owner
  - Action item
  - Due date
  - Status
  - Source reference
- Full MoM tab:
  - Editable structured document with:
    - Core Topic
    - Presenters/Host
    - Participants
    - Key Dates & Deadlines
    - Summary
    - Detailed Discussion Points
    - Decisions & Confirmations
    - Action Items table
    - Risks, Challenges & Dependencies
    - Additional Notes
- Transcript tab:
  - Searchable transcript.
  - Speaker labels and timestamps if available.
  - Button: Generate MoM again from this transcript.
- Right panel:
  - Review checklist
  - Version history
  - Regenerate controls:
    - Template selector
    - Output style selector
    - Button: Regenerate MoM
  - Do not show technical backend settings here unless Advanced is expanded.
- Export buttons:
  - Export PDF
  - Export DOCX
  - Export Email Draft
  - Copy Summary

Screen 6: Action Items
Create a central action tracker across all meetings.
- Table columns:
  - Action Item
  - Owner
  - Due Date
  - Status
  - Project
  - Source Meeting
  - Confidence
- Filters:
  - Owner
  - Project
  - Due date
  - Status
  - Meeting type
- Status values:
  - Open
  - In Progress
  - Blocked
  - Done
- Support inline editing.
- Each action item links back to the source meeting.
- Include quick views:
  - Due this week
  - Assigned to me
  - Blocked
  - No owner

Screen 7: Templates
Design a business-friendly template management area.
- Template list/cards:
  - Executive MoM
  - Project Review
  - Client Call
  - Townhall
  - Demo/UAT
  - Incident Review
- Each template shows:
  - Description
  - Last updated
  - Default status
  - Approval/locked status
- Template detail:
  - Sections included
  - Output preview
  - Sample generated MoM
  - Buttons: Use as Default, Duplicate, Edit, Test with Transcript
- Keep prompt details hidden behind Advanced/Prompt Studio.

Screen 8: Settings
Design settings for both normal users and admins.
Normal settings:
- Profile
- Default meeting type
- Default template
- Export preferences
- Notification preferences
- Privacy preferences

Admin/Advanced settings:
- Backend Configuration:
  - Dify
  - Azure OpenAI
  - Local Ollama
- ASR Configuration:
  - Whisper model
  - Language
  - VAD
  - faster-whisper/HF
- Storage & Retention:
  - Output folder
  - Save transcript
  - Save summary
  - Save email draft
  - Retention days
- Privacy & Compliance:
  - Local-only mode
  - Redact PII
  - Delete transcript after MoM
  - Audit logging
- Environment Health:
  - ffmpeg
  - Playwright
  - Python
  - Ollama model
  - Output folder writable
- Use masked secret inputs for API keys.
- Include Test All Connections button.
- Technical sections should look admin-only and should not dominate the product.

Screen 9: Animated Product Logo / Brand Identity
Create an animated logo concept for ECHO.

Logo direction:
- Executive, intelligent, precise, trustworthy.
- Combine audio waveform, meeting signal, echo/ripple, and structured outcomes.
- Avoid playful microphone icons or generic chat bubbles.
- Use a clean geometric mark that works beside the wordmark “ECHO”.
- The wordmark should be modern, uppercase, and professional.
- The mark should work as app icon, favicon, loading animation, and sidebar logo.

Animation concept:
- Start with a small signal pulse or waveform.
- Waveform expands into subtle concentric echo rings.
- Rings resolve into structured horizontal lines or checkmarks, representing highlights, decisions, and outcomes.
- Final frame locks into the ECHO logo mark plus wordmark.
- Duration: 1.5 to 2.5 seconds.
- Motion should be smooth, premium, and restrained.
- Use easing, subtle opacity fades, and line drawing effects.
- Avoid flashy neon, excessive bouncing, or cartoon motion.

Logo deliverables:
- Static logo mark.
- Horizontal logo lockup: icon + ECHO wordmark.
- App icon version.
- Light and dark theme variants.
- Loading animation storyboard with 5 keyframes.
- Optional Lottie-style animation direction.
- Usage examples in sidebar, loading screen, dashboard header, and empty states.

Important product requirements:
- ECHO must support multiple URLs and multiple uploaded recordings in a queue.
- ECHO must allow generating MoM again from already transcribed data without re-running transcription.
- ECHO must preserve history of meetings and segment them by type, project, owner, date, status, source, confidentiality, and tags.
- ECHO must support review, edit, approve, export, and regenerate workflows.
- ECHO must expose technical settings only in admin/advanced areas.
- ECHO must feel simple for non-technical users and powerful for admins.
- Use realistic sample data based on executive meetings, project reviews, townhalls, UAT handovers, incident reviews, client calls, and workplace policy calls.
