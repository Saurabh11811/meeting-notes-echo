import { X, Pause, RefreshCcw, AlertTriangle, CheckCircle2, Clock, FileText, Mic, Wand2 } from "lucide-react";

const jobs = [
  { title: "Q2 Board Pre-read — Steering Committee", status: "Creating MoM", progress: 78, started: "2 min ago", icon: Wand2, tone: "accent" },
  { title: "Partnership Call — Strategy", status: "Transcribing", progress: 42, started: "5 min ago", icon: Mic, tone: "info" },
  { title: "Karachi Incident Review", status: "Reading transcript", progress: 18, started: "6 min ago", icon: FileText, tone: "muted" },
  { title: "APAC FY26 Kickoff", status: "Waiting", progress: 0, started: "Queued", icon: Clock, tone: "muted" },
  { title: "UAT Handover — Booking Portal", status: "Needs attention", progress: 64, started: "8 min ago", icon: AlertTriangle, tone: "warning" },
  { title: "Customer Success Sync", status: "Completed", progress: 100, started: "12 min ago", icon: CheckCircle2, tone: "success" },
];

const toneBar: Record<string, string> = {
  accent: "bg-echo-accent",
  info: "bg-echo-info",
  muted: "bg-echo-text-faint",
  warning: "bg-echo-warning",
  success: "bg-echo-success",
};

export function ActivityDrawer({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <>
      <div onClick={onClose} className={`fixed inset-0 z-40 bg-black/30 transition-opacity ${open ? "opacity-100" : "opacity-0 pointer-events-none"}`} />
      <aside className={`fixed right-0 top-0 bottom-0 z-50 w-[420px] bg-echo-surface border-l border-echo-border shadow-2xl flex flex-col transition-transform ${open ? "translate-x-0" : "translate-x-full"}`}>
        <div className="h-[60px] px-5 flex items-center justify-between border-b border-echo-border">
          <div>
            <div className="text-[13px] text-echo-text" style={{ fontWeight: 600 }}>Activity</div>
            <div className="text-[10px] text-echo-text-faint mt-0.5">5 in progress · 1 needs attention · 1 completed</div>
          </div>
          <button onClick={onClose} className="h-8 w-8 grid place-items-center rounded-md text-echo-text-muted hover:bg-echo-surface-hover"><X size={15} /></button>
        </div>

        <div className="px-5 py-3 border-b border-echo-border bg-echo-surface-2 flex items-center gap-2">
          <button className="h-7 px-2.5 rounded-md border border-echo-border bg-echo-surface text-[11px] text-echo-text-muted inline-flex items-center gap-1.5"><Pause size={11} />Pause</button>
          <button className="h-7 px-2.5 rounded-md border border-echo-border bg-echo-surface text-[11px] text-echo-text-muted inline-flex items-center gap-1.5"><RefreshCcw size={11} />Retry attention</button>
          <button className="h-7 px-2.5 rounded-md border border-echo-border bg-echo-surface text-[11px] text-echo-text-muted ml-auto">Clear completed</button>
        </div>

        <div className="bg-amber-500/[0.08] border-b border-echo-border px-5 py-3 flex items-start gap-3">
          <div className="h-7 w-7 rounded-md bg-echo-surface border border-echo-border grid place-items-center text-echo-warning shrink-0"><AlertTriangle size={13} /></div>
          <div className="flex-1 text-[12px]">
            <div className="text-echo-text" style={{ fontWeight: 500 }}>UAT Handover — needs attention</div>
            <div className="text-echo-text-muted mt-0.5">We couldn't find a visible transcript. Upload the recording or check access.</div>
            <button className="mt-2 h-7 px-2.5 rounded-md bg-echo-text text-echo-surface text-[11px]">Fix and retry</button>
          </div>
        </div>

        <ul className="flex-1 overflow-y-auto divide-y divide-echo-border">
          {jobs.map((j) => {
            const Icon = j.icon;
            return (
              <li key={j.title} className="px-5 py-3 hover:bg-echo-surface-hover">
                <div className="flex items-start gap-3">
                  <div className="h-7 w-7 rounded-md bg-echo-surface-2 grid place-items-center text-echo-text-muted shrink-0"><Icon size={13} /></div>
                  <div className="flex-1 min-w-0">
                    <div className="text-[12.5px] text-echo-text truncate">{j.title}</div>
                    <div className="text-[10.5px] text-echo-text-muted mt-0.5">{j.status} · {j.started}</div>
                    <div className="mt-1.5 flex items-center gap-2">
                      <div className="flex-1 h-1 rounded-full bg-echo-surface-2 overflow-hidden">
                        <div className={`h-full ${toneBar[j.tone]}`} style={{ width: `${j.progress}%` }} />
                      </div>
                      <span className="text-[10px] text-echo-text-faint w-7 text-right">{j.progress}%</span>
                    </div>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      </aside>
    </>
  );
}
