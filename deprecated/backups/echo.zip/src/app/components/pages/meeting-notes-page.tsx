import { useMemo, useState } from "react";
import { PageHeader } from "../page-header";
import { Search, Download, Archive, ChevronDown, ChevronLeft, ChevronRight, ExternalLink, RefreshCw, X } from "lucide-react";

const allRows = [
  { title: "Q2 Board Pre-read — Steering Committee", date: "May 14", type: "Executive", participants: 12, decisions: 5, actions: 9, version: "v2", status: "Generated" },
  { title: "Logistics Account — Quarterly Business Review", date: "May 13", type: "Client Call", participants: 8, decisions: 3, actions: 6, version: "v1", status: "Generated" },
  { title: "FY26 Budget Walkthrough — Finance Council", date: "May 12", type: "Executive", participants: 14, decisions: 7, actions: 11, version: "v3", status: "Generated" },
  { title: "Hybrid Working Policy — Townhall", date: "May 12", type: "Townhall", participants: 240, decisions: 2, actions: 4, version: "v1", status: "Generated" },
  { title: "Customs Compliance Module — UAT Handover", date: "May 11", type: "Demo/UAT", participants: 9, decisions: 1, actions: 7, version: "v1", status: "Generated" },
  { title: "Karachi Outage — Incident Review", date: "May 10", type: "Incident", participants: 11, decisions: 4, actions: 12, version: "v2", status: "Generated" },
  { title: "Vessel Routing Optimization — Tech Review", date: "May 10", type: "Project Review", participants: 16, decisions: 6, actions: 8, version: "v2", status: "Generated" },
  { title: "Sustainability Strategy — H1 Review", date: "May 09", type: "Executive", participants: 10, decisions: 5, actions: 4, version: "v1", status: "Generated" },
  { title: "Cloud Migration Wave 4 — IT Steering", date: "May 08", type: "Project Review", participants: 18, decisions: 2, actions: 9, version: "v1", status: "Generated" },
  { title: "Customer Success Quarterly Sync", date: "May 08", type: "Client Call", participants: 7, decisions: 1, actions: 3, version: "v1", status: "Generated" },
  { title: "Treasury Strategy Update", date: "May 07", type: "Executive", participants: 9, decisions: 4, actions: 5, version: "v2", status: "Generated" },
  { title: "Data Platform Roadmap Review", date: "May 07", type: "Project Review", participants: 13, decisions: 3, actions: 7, version: "v1", status: "Generated" },
  { title: "Asia Trade Lane — Weekly Ops Sync", date: "May 06", type: "Project Review", participants: 11, decisions: 2, actions: 6, version: "v1", status: "Generated" },
  { title: "Compliance Standards — Briefing", date: "May 05", type: "Executive", participants: 6, decisions: 3, actions: 4, version: "v1", status: "Generated" },
  { title: "Procurement Quarterly Review", date: "May 05", type: "Project Review", participants: 12, decisions: 2, actions: 5, version: "v1", status: "Generated" },
];

const TYPES = ["All types", "Executive", "Project Review", "Client Call", "Townhall", "Demo/UAT", "Incident"];
const DATES = ["All time", "Last 7 days", "Last 30 days", "This quarter"];
const PAGE_SIZE = 10;

export function MeetingNotesPage({ onOpen }: { onOpen: () => void }) {
  const [q, setQ] = useState("");
  const [type, setType] = useState("All types");
  const [date, setDate] = useState("All time");
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    return allRows.filter((r) => {
      if (type !== "All types" && r.type !== type) return false;
      if (q && !r.title.toLowerCase().includes(q.toLowerCase())) return false;
      return true;
    });
  }, [q, type, date]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const slice = filtered.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);
  const start = (safePage - 1) * PAGE_SIZE + 1;
  const end = (safePage - 1) * PAGE_SIZE + slice.length;

  return (
    <div className="space-y-5">
      <PageHeader
        title="Meeting Notes"
        subtitle="Every generated MoM, searchable and filterable."
        actions={
          <>
            <button className="h-9 px-3 rounded-md border border-echo-border bg-echo-surface hover:bg-echo-surface-hover text-[12px] text-echo-text inline-flex items-center gap-1.5"><Download size={13} />Export</button>
            <button className="h-9 px-3 rounded-md border border-echo-border bg-echo-surface hover:bg-echo-surface-hover text-[12px] text-echo-text inline-flex items-center gap-1.5"><Archive size={13} />Archive</button>
          </>
        }
      />

      <section className="bg-echo-surface border border-echo-border rounded-lg overflow-hidden">
        {/* In-table toolbar */}
        <div className="px-3 py-2.5 border-b border-echo-border flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-2 flex-1 min-w-[260px] relative">
            <Search size={14} className="absolute left-3 text-echo-text-faint" />
            <input
              value={q}
              onChange={(e) => { setQ(e.target.value); setPage(1); }}
              placeholder="Search by meeting title, decision, or transcript content…"
              className="w-full h-9 pl-9 pr-8 rounded-md border border-echo-border bg-echo-surface-2 text-[13px] text-echo-text focus:outline-none focus:bg-echo-surface focus:border-echo-accent placeholder:text-echo-text-faint"
            />
            {q && (
              <button onClick={() => setQ("")} className="absolute right-2 text-echo-text-faint hover:text-echo-text"><X size={13} /></button>
            )}
          </div>

          <FilterDropdown label="Type" value={type} options={TYPES} onChange={(v) => { setType(v); setPage(1); }} />
          <FilterDropdown label="Date" value={date} options={DATES} onChange={(v) => { setDate(v); setPage(1); }} />

          <span className="text-[11px] text-echo-text-faint ml-auto">{filtered.length} results</span>
        </div>

        <table className="w-full text-[12px]">
          <thead className="bg-echo-surface-2 text-echo-text-muted">
            <tr>
              <th className="text-left px-5 py-2.5" style={{ fontWeight: 500 }}>Meeting</th>
              <th className="text-left px-3 py-2.5" style={{ fontWeight: 500 }}>Date</th>
              <th className="text-left px-3 py-2.5" style={{ fontWeight: 500 }}>Type</th>
              <th className="text-left px-3 py-2.5" style={{ fontWeight: 500 }}>People</th>
              <th className="text-left px-3 py-2.5" style={{ fontWeight: 500 }}>Decisions</th>
              <th className="text-left px-3 py-2.5" style={{ fontWeight: 500 }}>Actions</th>
              <th className="text-left px-3 py-2.5" style={{ fontWeight: 500 }}>Version</th>
              <th className="text-right px-5 py-2.5" style={{ fontWeight: 500 }}></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-echo-border">
            {slice.length === 0 && (
              <tr>
                <td colSpan={8} className="px-5 py-12 text-center text-[12px] text-echo-text-muted">No matches. Try a different keyword or filter.</td>
              </tr>
            )}
            {slice.map((r) => (
              <tr key={r.title} onClick={onOpen} className="hover:bg-echo-surface-hover cursor-pointer">
                <td className="px-5 py-3 text-echo-text">{r.title}</td>
                <td className="px-3 py-3 text-echo-text-muted">{r.date}</td>
                <td className="px-3 py-3"><span className="px-1.5 py-0.5 rounded bg-echo-surface-2 text-echo-text-muted text-[11px]">{r.type}</span></td>
                <td className="px-3 py-3 text-echo-text-muted">{r.participants}</td>
                <td className="px-3 py-3 text-echo-text">{r.decisions}</td>
                <td className="px-3 py-3 text-echo-text">{r.actions}</td>
                <td className="px-3 py-3 text-echo-text-muted">{r.version}</td>
                <td className="px-5 py-3" onClick={(e) => e.stopPropagation()}>
                  <div className="flex items-center justify-end gap-1 text-echo-text-faint">
                    <button onClick={onOpen} title="Open" className="h-7 w-7 grid place-items-center rounded hover:bg-echo-surface-hover hover:text-echo-text"><ExternalLink size={13} /></button>
                    <button title="Export" className="h-7 w-7 grid place-items-center rounded hover:bg-echo-surface-hover hover:text-echo-text"><Download size={13} /></button>
                    <button title="Regenerate" className="h-7 w-7 grid place-items-center rounded hover:bg-echo-surface-hover hover:text-echo-text"><RefreshCw size={13} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Pagination */}
        <div className="px-5 py-2.5 border-t border-echo-border flex items-center justify-between text-[11.5px] text-echo-text-muted">
          <div>{filtered.length === 0 ? "No results" : `Showing ${start}–${end} of ${filtered.length}`}</div>
          <div className="flex items-center gap-1">
            <button onClick={() => setPage(Math.max(1, safePage - 1))} disabled={safePage === 1} className="h-7 w-7 grid place-items-center rounded border border-echo-border bg-echo-surface hover:bg-echo-surface-hover disabled:opacity-40 disabled:cursor-not-allowed"><ChevronLeft size={13} /></button>
            <span className="px-2">Page {safePage} of {totalPages}</span>
            <button onClick={() => setPage(Math.min(totalPages, safePage + 1))} disabled={safePage === totalPages} className="h-7 w-7 grid place-items-center rounded border border-echo-border bg-echo-surface hover:bg-echo-surface-hover disabled:opacity-40 disabled:cursor-not-allowed"><ChevronRight size={13} /></button>
          </div>
        </div>
      </section>
    </div>
  );
}

function FilterDropdown({ label, value, options, onChange }: { label: string; value: string; options: string[]; onChange: (v: string) => void }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} className="h-9 px-2.5 rounded-md border border-echo-border bg-echo-surface text-[12px] text-echo-text inline-flex items-center gap-1.5 hover:bg-echo-surface-hover">
        <span className="text-echo-text-muted">{label}:</span>
        <span>{value}</span>
        <ChevronDown size={11} className="text-echo-text-faint" />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <ul className="absolute right-0 mt-1 z-20 min-w-[180px] bg-echo-surface border border-echo-border rounded-md shadow-lg py-1">
            {options.map((o) => (
              <li key={o}>
                <button onClick={() => { onChange(o); setOpen(false); }} className={`w-full text-left px-3 py-1.5 text-[12px] ${o === value ? "bg-echo-accent-bg text-echo-accent-fg" : "text-echo-text hover:bg-echo-surface-hover"}`}>
                  {o}
                </button>
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}
