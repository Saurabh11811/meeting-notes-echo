import { useState } from "react";
import { ArrowLeft, Share2, Download, RefreshCw, Calendar, Link2, FileText, ChevronRight, Copy, Mail, FileType2, Sparkles, AlertTriangle, Search } from "lucide-react";

const tabs = ["Executive Summary", "Decisions", "Action Items", "Risks & Blockers", "Full MoM", "Transcript", "Versions", "Exports"];

export function MeetingDetailPage({ onBack }: { onBack: () => void }) {
  const [tab, setTab] = useState("Executive Summary");

  return (
    <div className="space-y-5">
      <div>
        <button onClick={onBack} className="text-[12px] text-echo-text-muted hover:text-echo-text inline-flex items-center gap-1 mb-3"><ArrowLeft size={13} />Back to Meeting Notes</button>

        <div className="bg-echo-surface border border-echo-border rounded-lg p-5">
          <div className="flex items-start gap-4 flex-wrap">
            <div className="flex-1 min-w-[300px]">
              <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                <span className="text-[11px] px-1.5 py-0.5 rounded bg-echo-surface-2 text-echo-text-muted">Executive Review</span>
                <span className="text-[11px] px-1.5 py-0.5 rounded bg-echo-surface-2 text-echo-text-muted">Executive MoM template</span>
              </div>
              <h1 className="text-[20px] text-echo-text" style={{ fontWeight: 600 }}>Q2 Board Pre-read — Steering Committee</h1>
              <div className="mt-2 flex items-center gap-4 text-[12px] text-echo-text-muted flex-wrap">
                <span className="inline-flex items-center gap-1"><Calendar size={12} />May 14, 2026 · 10:00 AM</span>
                <span className="inline-flex items-center gap-1"><Link2 size={12} />Meeting recording</span>
                <span className="inline-flex items-center gap-1"><FileText size={12} />Transcript available</span>
                <span>v2 · regenerated 12 min ago</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button className="h-9 px-3 rounded-md border border-echo-border bg-echo-surface hover:bg-echo-surface-hover text-[12px] text-echo-text inline-flex items-center gap-1.5"><Share2 size={13} />Share</button>
              <button className="h-9 px-3 rounded-md border border-echo-border bg-echo-surface hover:bg-echo-surface-hover text-[12px] text-echo-text inline-flex items-center gap-1.5"><Download size={13} />Export</button>
              <button className="h-9 px-4 rounded-md bg-echo-accent hover:bg-echo-accent-hover text-white text-[12px] inline-flex items-center gap-1.5"><RefreshCw size={13} />Regenerate</button>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-5">
        <div className="space-y-3 min-w-0">
          <div className="bg-echo-surface border border-echo-border rounded-lg px-2 overflow-x-auto">
            <div className="flex gap-1">
              {tabs.map((t) => (
                <button key={t} onClick={() => setTab(t)} className={`px-3 py-2.5 text-[12px] whitespace-nowrap border-b-2 -mb-px ${tab === t ? "border-echo-accent text-echo-accent-fg" : "border-transparent text-echo-text-muted hover:text-echo-text"}`}>{t}</button>
              ))}
            </div>
          </div>

          <section className="bg-echo-surface border border-echo-border rounded-lg p-6 min-h-[420px]">
            {tab === "Executive Summary" && <ExecutiveSummary />}
            {tab === "Decisions" && <DecisionsTab />}
            {tab === "Action Items" && <ActionItemsTab />}
            {tab === "Risks & Blockers" && <RisksTab />}
            {tab === "Full MoM" && <FullMoMTab />}
            {tab === "Transcript" && <TranscriptTab />}
            {tab === "Versions" && <VersionsTab />}
            {tab === "Exports" && <ExportsTab />}
          </section>
        </div>

        <aside className="space-y-4">
          <section className="bg-echo-surface border border-echo-border rounded-lg">
            <div className="px-4 py-3 border-b border-echo-border text-[12px] text-echo-text" style={{ fontWeight: 600 }}>Regenerate</div>
            <div className="p-4 space-y-3 text-[12px]">
              <SelectField label="Template" value="Executive MoM" />
              <SelectField label="Output style" value="Concise · Board ready" />
              <button className="w-full h-9 rounded-md bg-echo-text text-echo-surface inline-flex items-center justify-center gap-1.5"><Sparkles size={13} />Regenerate MoM</button>
              <button className="w-full text-[11px] text-echo-text-muted hover:text-echo-text">Advanced options ▾</button>
            </div>
          </section>

          <section className="bg-echo-surface border border-echo-border rounded-lg">
            <div className="px-4 py-3 border-b border-echo-border text-[12px] text-echo-text" style={{ fontWeight: 600 }}>Version history</div>
            <ul className="p-2 text-[12px]">
              {[
                { v: "v2", who: "P. Sharma", when: "12 min ago", current: true },
                { v: "v1", who: "Automated", when: "1 hr ago" },
              ].map((v) => (
                <li key={v.v} className={`flex items-center justify-between px-2 py-2 rounded ${v.current ? "bg-echo-accent-bg" : "hover:bg-echo-surface-hover"}`}>
                  <div>
                    <div className="text-echo-text">{v.v}{v.current && <span className="ml-1.5 text-[10px] text-echo-accent-fg">current</span>}</div>
                    <div className="text-[10px] text-echo-text-muted">{v.who} · {v.when}</div>
                  </div>
                  <ChevronRight size={13} className="text-echo-text-faint" />
                </li>
              ))}
            </ul>
          </section>

          <section className="bg-echo-surface border border-echo-border rounded-lg">
            <div className="px-4 py-3 border-b border-echo-border text-[12px] text-echo-text" style={{ fontWeight: 600 }}>Export</div>
            <div className="p-3 grid grid-cols-2 gap-2 text-[11px]">
              <ExportBtn icon={<FileType2 size={13} />} label="PDF" />
              <ExportBtn icon={<FileText size={13} />} label="DOCX" />
              <ExportBtn icon={<Mail size={13} />} label="Email draft" />
              <ExportBtn icon={<Copy size={13} />} label="Copy summary" />
            </div>
          </section>
        </aside>
      </div>
    </div>
  );
}

function SelectField({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[10px] text-echo-text-muted mb-1 uppercase tracking-wide">{label}</div>
      <button className="w-full h-8 px-2 rounded-md border border-echo-border bg-echo-surface-2 text-left hover:bg-echo-surface-hover text-[12px] text-echo-text">{value}</button>
    </div>
  );
}
function ExportBtn({ icon, label }: { icon: React.ReactNode; label: string }) {
  return <button className="flex items-center gap-1.5 justify-center h-8 rounded border border-echo-border bg-echo-surface hover:bg-echo-surface-hover text-echo-text">{icon}{label}</button>;
}

function ExecutiveSummary() {
  return (
    <div className="space-y-5 text-[13px] text-echo-text leading-relaxed">
      <div>
        <h3 className="text-[11px] text-echo-text-muted uppercase tracking-wide mb-2">Brief summary</h3>
        <p>The steering committee reviewed Q2 performance against the strategic roadmap. Trade lane revenue is on plan, with APAC outperforming Europe by 4.2 ppts. The group endorsed accelerated investment in the Customs Compliance Module and approved the FY26 hiring envelope, contingent on a refreshed productivity baseline by end of June.</p>
      </div>
      <div className="grid grid-cols-2 gap-5">
        <SummaryCol title="Key outcomes" items={[
          "Q2 trade lane revenue tracking at 102% of plan",
          "APAC FY26 hiring envelope approved (+18 FTE)",
          "Customs Compliance Module advanced to wave 2",
          "Carbon-intensity targets to be revised by July board",
        ]} />
        <SummaryCol title="Important decisions" items={[
          "Proceed with partnership term sheet",
          "Approve $4.2M for compliance module wave 2",
          "Defer facility expansion to Q4",
        ]} />
        <SummaryCol title="Critical risks" items={[
          "Single-vendor dependency on terminal operations",
          "Sustainability disclosure window narrowing for H2",
        ]} danger />
        <SummaryCol title="Next steps" items={[
          "P. Sharma to brief July board on sustainability targets",
          "R. Kumar to finalize failover SLA by May 16",
          "Finance to publish productivity baseline by June 30",
        ]} />
      </div>
    </div>
  );
}

function SummaryCol({ title, items, danger }: { title: string; items: string[]; danger?: boolean }) {
  return (
    <div>
      <h3 className="text-[11px] text-echo-text-muted uppercase tracking-wide mb-2">{title}</h3>
      <ul className="list-disc pl-5 space-y-1">
        {items.map((i) => <li key={i} className={danger ? "text-echo-danger" : ""}>{i}</li>)}
      </ul>
    </div>
  );
}

function DecisionsTab() {
  const decisions = [
    { d: "Approve $4.2M budget for Customs Compliance Module wave 2", ctx: "Endorsed unanimously after review of UAT outcomes and compliance gaps in EU.", when: "00:42:18" },
    { d: "Proceed with partnership term sheet", ctx: "Conditional on legal review of failover SLA and exclusivity language.", when: "01:08:55" },
    { d: "Defer facility expansion to Q4", ctx: "Capacity utilization trending below threshold; revisit after incident review actions close.", when: "01:25:02" },
    { d: "Adopt revised carbon-intensity targets for H2 disclosure", ctx: "Aligns with new disclosure requirements; communications plan to follow.", when: "01:41:30" },
    { d: "Approve FY26 APAC hiring envelope (+18 FTE)", ctx: "Productivity baseline refresh due June 30 as gating condition.", when: "01:55:11" },
  ];
  return (
    <div className="divide-y divide-echo-border -mx-6 -my-6">
      {decisions.map((d, i) => (
        <div key={i} className="px-6 py-4">
          <div className="flex items-start gap-3">
            <div className="h-6 w-6 rounded-full bg-echo-accent-bg text-echo-accent-fg grid place-items-center text-[11px] shrink-0">{i + 1}</div>
            <div className="flex-1">
              <div className="text-[13px] text-echo-text" style={{ fontWeight: 500 }}>{d.d}</div>
              <p className="text-[12px] text-echo-text-muted mt-1">{d.ctx}</p>
              <div className="text-[11px] text-echo-text-muted mt-2">Transcript reference <span className="font-mono">{d.when}</span></div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function ActionItemsTab() {
  const items = [
    { task: "Brief July board on revised carbon-intensity targets", due: "Jun 28", ref: "01:41:30" },
    { task: "Finalize failover SLA terms", due: "May 16", ref: "01:09:50" },
    { task: "Publish refreshed productivity baseline", due: "Jun 30", ref: "01:55:11" },
    { task: "Circulate compliance module wave 2 plan", due: "May 20", ref: "00:42:18" },
    { task: "Legal review of exclusivity language", due: "May 18", ref: "01:08:55" },
  ];
  return (
    <table className="w-full text-[12px] -mx-6 -my-6" style={{ width: "calc(100% + 3rem)" }}>
      <thead className="bg-echo-surface-2 text-echo-text-muted">
        <tr>
          <th className="text-left px-6 py-2.5" style={{ fontWeight: 500 }}>Action</th>
          <th className="text-left px-3 py-2.5" style={{ fontWeight: 500 }}>Due</th>
          <th className="text-left px-6 py-2.5" style={{ fontWeight: 500 }}>Transcript ref</th>
        </tr>
      </thead>
      <tbody className="divide-y divide-echo-border">
        {items.map((a) => (
          <tr key={a.task} className="hover:bg-echo-surface-hover">
            <td className="px-6 py-3 text-echo-text">{a.task}</td>
            <td className="px-3 py-3 text-echo-text">{a.due}</td>
            <td className="px-6 py-3 text-echo-text-muted font-mono text-[11px]">{a.ref}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function RisksTab() {
  const risks = [
    { l: "Single-vendor dependency on terminal operator", severity: "High", mitigation: "Identify secondary operator and dual-source contingency by Q3." },
    { l: "Narrowing sustainability disclosure window for H2", severity: "High", mitigation: "Align carbon-intensity targets and disclosure plan before July board." },
    { l: "Productivity baseline pending — gates FY26 hiring", severity: "Medium", mitigation: "Finance to publish refreshed baseline by June 30." },
    { l: "Legal exclusivity terms not yet reviewed", severity: "Medium", mitigation: "Legal review owner assigned; due May 18." },
  ];
  return (
    <ul className="space-y-3">
      {risks.map((r) => (
        <li key={r.l} className="border border-echo-border rounded-md p-4 flex items-start gap-3 bg-echo-surface">
          <div className="h-8 w-8 rounded-md bg-rose-500/[0.12] grid place-items-center text-echo-danger shrink-0"><AlertTriangle size={14} /></div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <div className="text-[13px] text-echo-text">{r.l}</div>
              <span className={`text-[10px] px-1.5 py-0.5 rounded ${r.severity === "High" ? "bg-rose-500/[0.15] text-echo-danger" : "bg-amber-500/[0.15] text-echo-warning"}`}>{r.severity}</span>
            </div>
            <div className="text-[12px] text-echo-text-muted mt-1"><span className="text-echo-text-faint">Mitigation:</span> {r.mitigation}</div>
          </div>
        </li>
      ))}
    </ul>
  );
}

function FullMoMTab() {
  const sections: [string, string][] = [
    ["Core Topic", "Q2 strategic review and FY26 planning checkpoint."],
    ["Presenters / Host", "Priya Sharma (Chief of Staff); Anders Nielsen (Commercial); Rajan Kumar (Operations)."],
    ["Participants", "12 attendees including Executive Committee, Finance Council, and APAC Regional Lead."],
    ["Key Dates & Deadlines", "Productivity baseline refresh — June 30. Legal review — May 18. July board pre-read — June 28."],
    ["Summary", "Q2 tracking ahead of plan with APAC outperforming. Committee approved compliance module funding and FY26 hiring envelope, contingent on productivity baseline refresh."],
    ["Detailed Discussion Points", "Trade lane mix shift; partnership economics; capacity utilization; H2 sustainability disclosure; FY26 hiring strategy."],
    ["Decisions & Confirmations", "5 decisions captured — see Decisions tab."],
    ["Risks, Challenges & Dependencies", "4 risks captured — see Risks & Blockers tab."],
    ["Additional Notes", "Next steering committee scheduled for June 18; pre-read package due June 14."],
  ];
  return (
    <div className="space-y-5 text-[13px]">
      {sections.map(([h, body]) => (
        <div key={h}>
          <h3 className="text-[11px] text-echo-text-muted uppercase tracking-wide mb-1">{h}</h3>
          <p className="text-echo-text leading-relaxed">{body}</p>
        </div>
      ))}
      <div>
        <h3 className="text-[11px] text-echo-text-muted uppercase tracking-wide mb-2">Action items</h3>
        <ActionItemsTab />
      </div>
    </div>
  );
}

function TranscriptTab() {
  const turns = [
    { t: "10:02:14", s: "Priya Sharma", body: "Welcome everyone. We have a lot to cover today — Q2 results, the partnership term sheet, and the FY26 hiring envelope." },
    { t: "10:04:38", s: "Anders Nielsen", body: "On commercial — trade lane revenue is at 102% of plan. APAC is outperforming Europe by roughly 4.2 percentage points." },
    { t: "10:12:05", s: "Rajan Kumar", body: "I want to flag the terminal exposure. We had the incident two weeks ago and I'm concerned about single-vendor dependency." },
    { t: "10:25:40", s: "Lara Okafor", body: "On sustainability, the disclosure window is narrowing. We need revised carbon-intensity targets approved before the July board." },
    { t: "10:41:30", s: "Priya Sharma", body: "Agreed. I'll own the briefing for July board on the revised targets." },
  ];
  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <div className="flex-1 relative">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-echo-text-faint" />
          <input placeholder="Search this transcript…" className="w-full h-9 pl-9 pr-3 rounded-md border border-echo-border bg-echo-surface-2 text-[12px] text-echo-text focus:outline-none focus:bg-echo-surface focus:border-echo-accent" />
        </div>
        <button className="h-9 px-3 rounded-md bg-echo-text text-echo-surface text-[12px] inline-flex items-center gap-1.5"><Sparkles size={12} />Regenerate from transcript</button>
      </div>
      <ul className="space-y-3">
        {turns.map((t, i) => (
          <li key={i} className="flex items-start gap-3">
            <div className="text-[10px] font-mono text-echo-text-faint w-16 mt-0.5">{t.t}</div>
            <div className="flex-1">
              <div className="text-[12px] text-echo-accent-fg">{t.s}</div>
              <p className="text-[13px] text-echo-text">{t.body}</p>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function VersionsTab() {
  return (
    <div className="text-[13px] text-echo-text space-y-2">
      <div className="border border-echo-border rounded-md p-3 bg-echo-surface">
        <div className="flex items-center justify-between">
          <div><span className="text-echo-text">v2 (current)</span> · regenerated 12 min ago by P. Sharma</div>
          <button className="text-[11px] text-echo-accent">Compare</button>
        </div>
        <p className="text-[12px] text-echo-text-muted mt-1">Refined action item owners and tightened executive summary.</p>
      </div>
      <div className="border border-echo-border rounded-md p-3 bg-echo-surface">
        <div className="flex items-center justify-between">
          <div><span className="text-echo-text">v1</span> · generated 1 hr ago — automated</div>
          <button className="text-[11px] text-echo-accent">Restore</button>
        </div>
        <p className="text-[12px] text-echo-text-muted mt-1">Initial MoM from meeting recording transcript.</p>
      </div>
    </div>
  );
}

function ExportsTab() {
  return (
    <div className="grid grid-cols-2 gap-3 text-[12px]">
      {["PDF — Board ready", "DOCX — Editable", "Email draft (HTML)", "Action items CSV", "Plain text summary", "Shared link"].map((x) => (
        <button key={x} className="flex items-center justify-between px-4 py-3 border border-echo-border rounded-md hover:bg-echo-surface-hover text-left">
          <div>
            <div className="text-echo-text">{x}</div>
            <div className="text-[11px] text-echo-text-muted mt-0.5">Last generated 12 min ago</div>
          </div>
          <Download size={14} className="text-echo-text-faint" />
        </button>
      ))}
    </div>
  );
}
