import { useState } from "react";
import { PageHeader } from "../page-header";
import { User, Bell, Download, Shield, Server, Mic, Database, Lock, Activity, FlaskRound, KeyRound, CheckCircle2, ChevronRight } from "lucide-react";

const sections = [
  { id: "profile", label: "Profile", icon: User, group: "Personal" },
  { id: "defaults", label: "Defaults", icon: Download, group: "Personal" },
  { id: "notifications", label: "Notifications", icon: Bell, group: "Personal" },
  { id: "privacy", label: "Privacy preferences", icon: Shield, group: "Personal" },
  { id: "health", label: "System Health", icon: Activity, group: "Admin", admin: true },
  { id: "backend", label: "Backend Settings", icon: Server, group: "Admin", admin: true },
  { id: "prompt", label: "Prompt Studio", icon: FlaskRound, group: "Admin", admin: true },
  { id: "asr", label: "ASR Configuration", icon: Mic, group: "Admin", admin: true },
  { id: "storage", label: "Storage & Retention", icon: Database, group: "Admin", admin: true },
  { id: "compliance", label: "Privacy & Compliance", icon: Lock, group: "Admin", admin: true },
];

export function SettingsPage() {
  const [sel, setSel] = useState("profile");
  return (
    <div className="space-y-5">
      <PageHeader title="Settings" subtitle="Personal preferences and admin-only configuration." />

      <div className="grid grid-cols-1 xl:grid-cols-[260px_1fr] gap-5">
        <aside className="bg-echo-surface border border-echo-border rounded-lg p-2 h-fit">
          {["Personal", "Admin"].map((g) => (
            <div key={g} className="mb-1">
              <div className="px-3 pt-2 pb-1 text-[10px] uppercase tracking-wider text-echo-text-faint">{g}</div>
              {sections.filter((s) => s.group === g).map((s) => {
                const I = s.icon;
                const active = sel === s.id;
                return (
                  <button key={s.id} onClick={() => setSel(s.id)} className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-[12px] ${active ? "bg-echo-accent-bg text-echo-accent-fg" : "text-echo-text hover:bg-echo-surface-hover"}`}>
                    <I size={14} className={active ? "text-echo-accent" : "text-echo-text-muted"} />
                    <span className="flex-1 text-left">{s.label}</span>
                    {s.admin && <span className="text-[9px] px-1 rounded bg-echo-surface-2 text-echo-text-muted">ADMIN</span>}
                  </button>
                );
              })}
            </div>
          ))}
        </aside>

        <section className="space-y-5">
          {sel === "profile" && <ProfilePanel />}
          {sel === "defaults" && <DefaultsPanel />}
          {sel === "notifications" && <NotificationsPanel />}
          {sel === "privacy" && <PrivacyPanel />}
          {sel === "health" && <HealthPanel />}
          {sel === "backend" && <BackendPanel />}
          {sel === "prompt" && <PromptStudioPanel />}
          {sel === "asr" && <ASRPanel />}
          {sel === "storage" && <StoragePanel />}
          {sel === "compliance" && <CompliancePanel />}
        </section>
      </div>
    </div>
  );
}

function Panel({ title, desc, children }: { title: string; desc?: string; children: React.ReactNode }) {
  return (
    <div className="bg-echo-surface border border-echo-border rounded-lg">
      <div className="px-5 py-3 border-b border-echo-border">
        <h2 className="text-[14px] text-echo-text" style={{ fontWeight: 600 }}>{title}</h2>
        {desc && <p className="text-[12px] text-echo-text-muted mt-0.5">{desc}</p>}
      </div>
      <div className="p-5 space-y-4">{children}</div>
    </div>
  );
}
function Row({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-[200px_1fr] gap-4 items-start">
      <div>
        <div className="text-[12px] text-echo-text">{label}</div>
        {hint && <div className="text-[11px] text-echo-text-muted mt-0.5">{hint}</div>}
      </div>
      <div>{children}</div>
    </div>
  );
}
function Input({ value, type = "text" }: { value: string; type?: string }) {
  return <input type={type} defaultValue={value} className="w-full max-w-md h-9 px-3 rounded-md border border-echo-border bg-echo-surface-2 text-[12px] text-echo-text focus:outline-none focus:bg-echo-surface focus:border-echo-accent" />;
}
function Toggle({ on = false, label }: { on?: boolean; label: string }) {
  const [v, setV] = useState(on);
  return (
    <label className="inline-flex items-center gap-2 cursor-pointer">
      <button onClick={() => setV(!v)} className={`h-5 w-9 rounded-full transition-colors relative ${v ? "bg-echo-accent" : "bg-echo-border-strong"}`}>
        <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all ${v ? "left-4" : "left-0.5"}`} />
      </button>
      <span className="text-[12px] text-echo-text-muted">{label}</span>
    </label>
  );
}

function ProfilePanel() {
  return (
    <Panel title="Profile" desc="How you appear inside ECHO.">
      <div className="flex items-center gap-4">
        <div className="h-14 w-14 rounded-full text-white grid place-items-center text-[18px]" style={{ background: "linear-gradient(135deg, var(--echo-accent), var(--echo-accent-hover))" }}>PS</div>
        <button className="h-8 px-3 rounded-md border border-echo-border bg-echo-surface text-[12px] text-echo-text">Change photo</button>
      </div>
      <Row label="Full name"><Input value="Priya Sharma" /></Row>
      <Row label="Email"><Input value="priya.sharma@company.com" type="email" /></Row>
      <Row label="Role"><Input value="Chief of Staff" /></Row>
      <Row label="Time zone"><Input value="Europe/Copenhagen (CET)" /></Row>
    </Panel>
  );
}
function DefaultsPanel() {
  return (
    <Panel title="Defaults" desc="Pre-fill values used when creating MoMs.">
      <Row label="Default meeting type"><Input value="Executive Review" /></Row>
      <Row label="Default template"><Input value="Executive MoM" /></Row>
      <Row label="Default export format"><Input value="PDF · Board ready" /></Row>
      <Row label="Confidentiality default"><Input value="Internal" /></Row>
    </Panel>
  );
}
function NotificationsPanel() {
  return (
    <Panel title="Notifications">
      <Row label="MoM ready for review"><Toggle on label="In-app and email" /></Row>
      <Row label="Action item due soon"><Toggle on label="Email reminder 24 hours before" /></Row>
      <Row label="Queue needs attention"><Toggle on label="In-app" /></Row>
      <Row label="Weekly digest"><Toggle label="Email each Monday 8:00 AM" /></Row>
    </Panel>
  );
}
function PrivacyPanel() {
  return (
    <Panel title="Privacy preferences">
      <Row label="Hide my MoMs from workspace search" hint="Other admins can still find them."><Toggle label="Enable" /></Row>
      <Row label="Mask participant emails in exports"><Toggle on label="Replace with initials" /></Row>
      <Row label="Auto-redact phone numbers"><Toggle on label="Enabled" /></Row>
    </Panel>
  );
}

function HealthPanel() {
  const checks = [
    { l: "ffmpeg", v: "v6.1 · healthy", ok: true },
    { l: "Playwright", v: "v1.45 · healthy", ok: true },
    { l: "Python runtime", v: "3.11.7 · healthy", ok: true },
    { l: "Ollama model", v: "llama3:70b · loaded", ok: true },
    { l: "Output folder writable", v: "/var/echo/output · OK", ok: true },
    { l: "Network egress (Azure OpenAI)", v: "120 ms · OK", ok: true },
  ];
  return (
    <Panel title="System Health" desc="Read-only environment diagnostics for admins.">
      <div className="flex items-center justify-between">
        <div className="text-[12px] text-echo-text-muted">Last checked 2 minutes ago</div>
        <button className="h-9 px-3 rounded-md bg-echo-text text-echo-surface text-[12px]">Test all connections</button>
      </div>
      <ul className="divide-y divide-echo-border border border-echo-border rounded-md">
        {checks.map((c) => (
          <li key={c.l} className="px-4 py-2.5 flex items-center gap-3">
            <CheckCircle2 size={14} className={c.ok ? "text-echo-success" : "text-echo-danger"} />
            <span className="text-[12px] text-echo-text flex-1">{c.l}</span>
            <span className="text-[12px] text-echo-text-muted">{c.v}</span>
          </li>
        ))}
      </ul>
    </Panel>
  );
}

function BackendPanel() {
  return (
    <Panel title="Backend Settings" desc="Switch between Dify, Azure OpenAI, and local Ollama.">
      <Row label="Primary backend">
        <div className="inline-flex p-1 bg-echo-surface-2 rounded-md border border-echo-border">
          {["Dify", "Azure OpenAI", "Local Ollama"].map((b, i) => (
            <button key={b} className={`px-3 py-1.5 rounded text-[12px] ${i === 1 ? "bg-echo-surface text-echo-text shadow-sm" : "text-echo-text-muted"}`}>{b}</button>
          ))}
        </div>
      </Row>
      <Row label="Azure OpenAI endpoint"><Input value="https://workspace-openai.azure.com/" /></Row>
      <Row label="Azure OpenAI API key" hint="Stored encrypted at rest.">
        <div className="flex items-center gap-2">
          <Input value="••••••••••••••••" />
          <button className="text-[11px] text-echo-accent inline-flex items-center gap-1"><KeyRound size={11} />Reveal</button>
        </div>
      </Row>
      <Row label="Deployment / model"><Input value="gpt-4o-2026-04-01 (echo-summary)" /></Row>
      <Row label="Dify base URL"><Input value="https://dify.internal.company.com" /></Row>
      <Row label="Ollama base URL"><Input value="http://localhost:11434" /></Row>
    </Panel>
  );
}

function PromptStudioPanel() {
  const prompts = ["Executive MoM — synthesis", "Action item extraction", "Risk classification", "Email draft from MoM"];
  return (
    <Panel title="Prompt Studio" desc="Manage system prompts and templates. Locked by default.">
      <ul className="border border-echo-border rounded-md divide-y divide-echo-border">
        {prompts.map((p, i) => (
          <li key={p} className="px-4 py-2.5 flex items-center gap-3 hover:bg-echo-surface-hover cursor-pointer">
            <FlaskRound size={13} className="text-echo-text-muted" />
            <div className="flex-1">
              <div className="text-[12px] text-echo-text">{p}</div>
              <div className="text-[11px] text-echo-text-muted">v{3 - (i % 2)} · last edited {i + 2} days ago</div>
            </div>
            <Lock size={12} className="text-echo-text-faint" />
            <ChevronRight size={14} className="text-echo-text-faint" />
          </li>
        ))}
      </ul>
    </Panel>
  );
}

function ASRPanel() {
  return (
    <Panel title="ASR Configuration" desc="Speech-to-text settings for recordings without transcripts.">
      <Row label="Whisper model"><Input value="faster-whisper · large-v3" /></Row>
      <Row label="Language"><Input value="Auto-detect (fallback: English)" /></Row>
      <Row label="Voice activity detection (VAD)"><Toggle on label="Silero VAD" /></Row>
      <Row label="HuggingFace cache path"><Input value="/var/echo/models/hf" /></Row>
    </Panel>
  );
}

function StoragePanel() {
  return (
    <Panel title="Storage & Retention">
      <Row label="Output folder"><Input value="/var/echo/output" /></Row>
      <Row label="Save transcript"><Toggle on label="Keep raw transcript with MoM" /></Row>
      <Row label="Save summary"><Toggle on label="Always" /></Row>
      <Row label="Save email draft"><Toggle label="Only when requested" /></Row>
      <Row label="Retention period (days)"><Input value="365" type="number" /></Row>
    </Panel>
  );
}

function CompliancePanel() {
  return (
    <Panel title="Privacy & Compliance">
      <Row label="Local-only mode" hint="No data leaves the workspace network."><Toggle label="Disabled" /></Row>
      <Row label="Redact PII automatically"><Toggle on label="Names, emails, phone numbers" /></Row>
      <Row label="Delete transcript after MoM"><Toggle label="Keep transcript by default" /></Row>
      <Row label="Audit logging"><Toggle on label="All MoM access logged" /></Row>
    </Panel>
  );
}
