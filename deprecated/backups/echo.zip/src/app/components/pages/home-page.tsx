import { useState } from "react";
import { Link2, Upload, FileText, Sparkles, ChevronDown, Wand2, Mic, Clock, AlertTriangle, X, Plus, Layers } from "lucide-react";

const tabs = [
  { id: "links", label: "Meeting Links", icon: Link2 },
  { id: "upload", label: "Upload Recordings", icon: Upload },
  { id: "transcript", label: "Existing Transcript", icon: FileText },
];

const inProgress = [
  { title: "Q2 Board Pre-read — Steering Committee", status: "Creating MoM", progress: 78, icon: Wand2, tone: "accent" },
  { title: "Partnership Call — Strategy Sync", status: "Transcribing", progress: 42, icon: Mic, tone: "info" },
  { title: "APAC FY26 Kickoff", status: "Waiting", progress: 0, icon: Clock, tone: "muted" },
  { title: "UAT Handover — Booking Portal", status: "Needs attention", progress: 64, icon: AlertTriangle, tone: "warning" },
];

const recent = [
  { title: "Client QBR — Logistics Account", date: "May 13", type: "Client Call", status: "Generated", tone: "success" },
  { title: "FY26 Budget Walkthrough", date: "May 12", type: "Executive", status: "Generated", tone: "success" },
  { title: "Hybrid Working Townhall", date: "May 12", type: "Townhall", status: "Generated", tone: "success" },
  { title: "Customs Compliance — UAT Handover", date: "May 11", type: "Demo/UAT", status: "Generated", tone: "success" },
  { title: "Karachi Outage — Incident Review", date: "May 10", type: "Incident", status: "Generated", tone: "success" },
];

const toneBar: Record<string, string> = {
  accent: "bg-echo-accent",
  info: "bg-echo-info",
  muted: "bg-echo-text-faint",
  warning: "bg-echo-warning",
  success: "bg-echo-success",
};
const toneText: Record<string, string> = {
  accent: "text-echo-accent",
  info: "text-echo-info",
  muted: "text-echo-text-muted",
  warning: "text-echo-warning",
  success: "text-echo-success",
};

export function HomePage({ onOpenReview }: { onOpenReview: () => void }) {
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-[22px] text-echo-text" style={{ fontWeight: 600 }}>Good afternoon, Priya</h1>
        <p className="text-[13px] text-echo-text-muted mt-1">Convert a meeting into professional minutes in under a minute.</p>
      </div>

      <CreateBlock />

      <div className="grid grid-cols-1 xl:grid-cols-5 gap-5">
        <InProgressCard className="xl:col-span-2" />
        <RecentCard className="xl:col-span-3" onOpen={onOpenReview} />
      </div>
    </div>
  );
}

function CreateBlock() {
  const [active, setActive] = useState("links");
  const [bulk, setBulk] = useState(false);
  const [files, setFiles] = useState<string[]>([]);

  const addFile = () => setFiles((f) => [...f, `Recording ${f.length + 1}.mp4`]);

  return (
    <section className="bg-echo-surface border border-echo-border rounded-lg shadow-[var(--echo-shadow)]">
      <div className="px-6 pt-5 pb-4 flex items-start justify-between gap-4 border-b border-echo-border">
        <div>
          <h2 className="text-[16px] text-echo-text" style={{ fontWeight: 600 }}>Create meeting notes</h2>
          <p className="text-[12px] text-echo-text-muted mt-1">Paste a meeting link, upload a recording, or reuse a transcript.</p>
        </div>
        <label className="flex items-center gap-2 text-[12px] text-echo-text-muted cursor-pointer select-none">
          <span>Bulk mode</span>
          <button onClick={() => setBulk(!bulk)} className={`h-5 w-9 rounded-full transition-colors relative ${bulk ? "bg-echo-accent" : "bg-echo-border-strong"}`}>
            <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all ${bulk ? "left-4" : "left-0.5"}`} />
          </button>
        </label>
      </div>

      <div className="px-6 pt-4">
        <div className="inline-flex p-1 rounded-md bg-echo-surface-2 border border-echo-border">
          {tabs.map((t) => {
            const Icon = t.icon;
            const isActive = active === t.id;
            return (
              <button key={t.id} onClick={() => setActive(t.id)} className={`flex items-center gap-2 px-3 py-1.5 rounded text-[12px] transition-colors ${isActive ? "bg-echo-surface text-echo-text shadow-sm" : "text-echo-text-muted hover:text-echo-text"}`}>
                <Icon size={13} />{t.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="px-6 py-4">
        {active === "links" && (
          <textarea
            placeholder={bulk ? "Paste multiple meeting links, one per line…" : "Paste a meeting link…"}
            className="w-full h-24 p-3 rounded-md border border-echo-border bg-echo-surface-2 text-[13px] font-mono text-echo-text placeholder:text-echo-text-faint focus:outline-none focus:bg-echo-surface focus:border-echo-accent"
          />
        )}

        {active === "upload" && (
          <div>
            <div onClick={addFile} className="border-2 border-dashed border-echo-border rounded-md py-8 px-6 bg-echo-surface-2 text-center hover:border-echo-accent hover:bg-echo-accent-bg/40 cursor-pointer transition-colors">
              <div className="mx-auto h-9 w-9 rounded-full bg-echo-surface border border-echo-border grid place-items-center mb-2"><Upload size={14} className="text-echo-accent" /></div>
              <div className="text-[13px] text-echo-text">Drop {bulk ? "multiple " : ""}audio or video files</div>
              <div className="text-[11px] text-echo-text-muted mt-1">MP4, MP3, M4A, WAV, MOV{bulk ? " · multiple supported" : ""}</div>
            </div>
            {files.length > 0 && (
              <ul className="mt-3 space-y-1.5">
                {files.map((f, i) => (
                  <li key={i} className="flex items-center gap-2 px-3 py-2 rounded-md border border-echo-border bg-echo-surface-2 text-[12px]">
                    <FileText size={12} className="text-echo-text-muted" />
                    <span className="flex-1 truncate text-echo-text">{f}</span>
                    <span className="text-[10px] text-echo-text-faint">Ready</span>
                    <button onClick={() => setFiles(files.filter((_, idx) => idx !== i))} className="text-echo-text-faint hover:text-echo-danger"><X size={12} /></button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}

        {active === "transcript" && (
          <textarea placeholder="Paste transcript text or select a saved transcript…" className="w-full h-24 p-3 rounded-md border border-echo-border bg-echo-surface-2 text-[13px] text-echo-text placeholder:text-echo-text-faint focus:outline-none focus:bg-echo-surface focus:border-echo-accent" />
        )}
      </div>

      <div className="px-6 py-3 border-t border-echo-border bg-echo-surface-2/50 rounded-b-lg flex items-center gap-3 flex-wrap">
        <OptionSelect label="Type" value="Executive Review" />
        <OptionSelect label="Template" value="Executive MoM" />
        <button className="text-[11px] text-echo-text-muted hover:text-echo-text ml-auto">Advanced ▾</button>

        <div className="w-full flex items-center gap-2 pt-1">
          <button className="inline-flex items-center gap-2 h-9 px-4 rounded-md bg-echo-accent hover:bg-echo-accent-hover text-white text-[13px] shadow-sm" style={{ color: "#fff" }}>
            <Sparkles size={14} />
            {bulk ? "Generate all MoMs" : "Generate MoM"}
          </button>
          {bulk && (
            <button className="inline-flex items-center gap-2 h-9 px-3 rounded-md border border-echo-border bg-echo-surface text-echo-text text-[13px] hover:bg-echo-surface-hover">
              <Layers size={14} />
              Queue for later
            </button>
          )}
          <button className="inline-flex items-center gap-1 h-9 px-3 rounded-md text-echo-text-muted hover:text-echo-text text-[13px]">
            <Plus size={14} />
            Save as draft
          </button>
        </div>
      </div>
    </section>
  );
}

function OptionSelect({ label, value }: { label: string; value: string }) {
  return (
    <button className="flex items-center gap-2 h-8 px-2.5 rounded-md border border-echo-border bg-echo-surface hover:border-echo-border-strong text-[12px]">
      <span className="text-echo-text-muted">{label}:</span>
      <span className="text-echo-text">{value}</span>
      <ChevronDown size={11} className="text-echo-text-faint" />
    </button>
  );
}

function InProgressCard({ className = "" }: { className?: string }) {
  return (
    <section className={`bg-echo-surface border border-echo-border rounded-lg ${className}`}>
      <SectionHeader title="In progress" subtitle={`${inProgress.length} jobs`} action="View activity" />
      <ul className="divide-y divide-echo-border">
        {inProgress.map((j) => {
          const Icon = j.icon;
          return (
            <li key={j.title} className="px-5 py-3 hover:bg-echo-surface-hover">
              <div className="flex items-center gap-3">
                <div className="h-7 w-7 rounded-md bg-echo-surface-2 grid place-items-center text-echo-text-muted shrink-0"><Icon size={13} /></div>
                <div className="flex-1 min-w-0">
                  <div className="text-[12.5px] text-echo-text truncate">{j.title}</div>
                  <div className={`text-[10.5px] mt-0.5 ${toneText[j.tone]}`}>{j.status}</div>
                </div>
                <div className="w-12 text-right text-[10px] text-echo-text-faint">{j.progress}%</div>
              </div>
              <div className="mt-2 h-1 rounded-full bg-echo-surface-2 overflow-hidden ml-10">
                <div className={`h-full ${toneBar[j.tone]}`} style={{ width: `${j.progress}%` }} />
              </div>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

function RecentCard({ className = "", onOpen }: { className?: string; onOpen: () => void }) {
  return (
    <section className={`bg-echo-surface border border-echo-border rounded-lg overflow-hidden ${className}`}>
      <SectionHeader title="Recent meeting notes" subtitle="Last 7 days" action="Open archive" />
      <table className="w-full text-[12px]">
        <thead className="bg-echo-surface-2 text-echo-text-muted">
          <tr>
            <th className="text-left px-5 py-2.5" style={{ fontWeight: 500 }}>Meeting</th>
            <th className="text-left px-3 py-2.5" style={{ fontWeight: 500 }}>Date</th>
            <th className="text-left px-3 py-2.5" style={{ fontWeight: 500 }}>Type</th>
            <th className="text-left px-5 py-2.5" style={{ fontWeight: 500 }}>Status</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-echo-border">
          {recent.map((n) => (
            <tr key={n.title} onClick={onOpen} className="hover:bg-echo-surface-hover cursor-pointer">
              <td className="px-5 py-2.5 text-echo-text">{n.title}</td>
              <td className="px-3 py-2.5 text-echo-text-muted">{n.date}</td>
              <td className="px-3 py-2.5"><span className="px-1.5 py-0.5 rounded bg-echo-surface-2 text-echo-text-muted text-[11px]">{n.type}</span></td>
              <td className="px-5 py-2.5">
                <span className="inline-flex items-center gap-1.5 text-[11px] text-echo-text">
                  <span className={`h-1.5 w-1.5 rounded-full ${toneBar[n.tone]}`} />
                  {n.status}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}

function SectionHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: string }) {
  return (
    <div className="px-5 py-3 flex items-center justify-between border-b border-echo-border">
      <div className="flex items-baseline gap-2">
        <h3 className="text-[13px] text-echo-text" style={{ fontWeight: 600 }}>{title}</h3>
        {subtitle && <span className="text-[11px] text-echo-text-muted">{subtitle}</span>}
      </div>
      {action && <button className="text-[11.5px] text-echo-accent hover:text-echo-accent-hover">{action} →</button>}
    </div>
  );
}
